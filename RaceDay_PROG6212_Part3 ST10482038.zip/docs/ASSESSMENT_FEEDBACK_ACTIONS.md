# Previous Part 2 result: feedback and changes

The prior result was **76/100 (76%)**. The assessor awarded 20/20 for authentication, 23/25 for endpoints/database, 9/10 for Swagger, 13/15 for tests, 8/10 for GitHub/CI, 3/5 for submission structure, and 0/15 for the missing video.

| Criterion | Feedback received | Change in this package / evidence still needed |
|---|---|---|
| Correct submission | Duplicate source folders and incomplete README placeholders | One solution root now contains API, MVC, shared contracts, tests, migration, database plan and setup documentation. The README explains local, Azure and Docker setup. Add your public repository URL and final submission evidence after publishing. |
| GitHub and CI/CD | 23 commits and a successful workflow existed, but the uploaded source omitted the workflow | `.github/workflows/ci.yml` is included and builds/tests the solution and builds the MVC container. Push it to your GitHub repository and capture the real green Actions run. Commits must be made from your own GitHub account. |
| Authentication and roles | Full marks | Kept the API's salted password hashes, server-side sessions, role checks and ownership checks. The MVC website now keeps role-aware menus and forwards the API session cookie. |
| API and database | Results could be recorded before an event; finishing times/places needed better handling | Results are refused until the event date/time has passed; invalid/zero times and duplicate places within an event category are rejected. New integration cases cover these checks. Apply all migrations before running against SQL Server. |
| Swagger | Missing evidence of a running Swagger page | Swagger remains enabled with XML docs and endpoint response descriptions. Open `/swagger` while the API is running and include a screenshot in your submission/video. |
| Unit tests | Add categories, profile, result and validation cases | Existing integration tests cover all resources; new result timing and position tests were added. Run the test command in the README and retain the real output. |
| Video presentation | Compulsory video was not submitted | Record and upload an unlisted video using `VIDEO_DEMO_SCRIPT.md`; insert its real URL in the README. A script cannot substitute for the recording. |

## Part 3 implementation

The MVC site consumes the API and includes authentication, role-based navigation, organiser event/category/enrolment/result pages, participant browse/entry/results/profile pages, Azure Blob upload routes and a multi-stage Dockerfile. Configure Azure Storage to demonstrate uploads. The Docker container hosts MVC; SQL Server and the API must remain reachable separately.
