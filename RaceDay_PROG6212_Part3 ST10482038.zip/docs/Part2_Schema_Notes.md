# Part 2 and Part 3 schema notes

`RaceDay_ERD.pdf` and `RaceDay_Database.sql` are retained as the Part 1 planning artefacts. The running API's EF Core migrations are the authoritative executable schema for this solution.

The Part 2 brief requires fields and links that were not present in the Part 1 schema:

- `Events.DistanceKm` and `Events.EventType` store the event distance and whether it is a run, walk or cycle.
- `Enrolments.EventId` stores the event link directly as well as the selected category and participant.

Part 3 adds optional `Events.BannerImageUrl` and `Users.ProfileImageUrl` values. Migration `20261109090000_AddImageUrls` adds those nullable columns to an existing Part 2 database. Apply all migrations with `dotnet ef database update --project RaceDay.Api`.

The additions are deliberate: they satisfy Part 2/Part 3 functional requirements while retaining the Part 1 roles, users, event/category relationships, enrolment status, results, and restrictive delete behavior. Do not run the old Part 1 SQL seed script against the EF Core database; use EF migrations for the application database.
